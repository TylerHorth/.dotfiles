/*********************************************** 
 * Name: Tyler Horth
 * Student ID: 20559378
 * File: test-sint.c 
 * CS 136 Winter 2015 - Assignment 6, Problem 2
 * Description: A program for testing sint.c 
***********************************************/

#include "sint.h"
#include <string.h>
#include <stdio.h>

// stringEquals(s1, s2) assigns each element of s1 
// to the corrosponding element of s2
// requires: s1 and s2 are null terminated strings
void stringEquals(char s1[], const char s2[]) {
	for (int i = 0; s2[i] != '\0'; i++) {
		s1[i] = s2[i];
		s1[i+1] = '\0';
	}
}

int main(void) {
	struct sint input = {"0"};
	struct sint min = {"0"};
	struct sint max = {"0"};
	struct sint sum = {"0"};
	int init = 1;
  while (scanf("%s", input.digits) != EOF) {
		if (init) {
			stringEquals(min.digits, input.digits);
			stringEquals(max.digits, input.digits);
			init = 0;
		} else if (scomp(&input, &min) == -1) {
			stringEquals(min.digits, input.digits);
		} else if (scomp(&input, &max) == 1) {
			stringEquals(max.digits, input.digits);
		}
		stringEquals(sum.digits, sadd(&sum, &input).digits);
	}
	strim(&min);
	strim(&max);
	strim(&sum);
	printf("min:%s\n", min.digits);
	printf("max:%s\n", max.digits);
	printf("sum:%s\n", sum.digits);
}
