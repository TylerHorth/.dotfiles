/*********************************************** 
 * Name: Tyler Horth
 * Student ID: 20559378
 * File: sint.c 
 * CS 136 Winter 2015 - Assignment 6, Problem 2
 * Description: A module for simple string
 *  arithmetic operations
***********************************************/

#include "sint.h"
#include <assert.h>
#include <stdlib.h>
#include <string.h>

void strim(struct sint *a) {
	assert(a != NULL);
	int zeros = 0;
	int total = 0;
	int lead = 1;
	for (int i = 0; a->digits[i] != '\0'; i++) {
		if (lead && a->digits[i] == '0') {
			zeros++; 
		} else {
			lead = 0;
		}
		total++;
	}
	for (int i = 0; i < total; i++) {
		if (zeros + i < total) { 
			a->digits[i] = a->digits[zeros + i];
		}	else {
			a->digits[i] = 0;
		}
	}
	if (a->digits[0] == '\0') {
		a->digits[0] = '0';
		a->digits[1] = '\0';
	}
}

// pad(a, b) adds 0's to the begining of the digits in 
// a and b until they are the same length plus 1 additional
// leading zero.
// requires: a and b are not null
void pad(struct sint *a, struct sint *b) {
	assert(a != NULL && b != NULL);
	int aLen = strlen(a->digits) + 1;
	int bLen = strlen(b->digits) + 1;
	int diff = aLen - bLen;
	for (int i = (diff > 0) ? aLen : bLen; i > 0; i--) {
		a->digits[i] = a->digits[i-1];
		b->digits[i] = b->digits[i-1];
	}	
	a->digits[0] = '0';
	b->digits[0] = '0';
	if (diff < 0) {
		diff = -diff;
		for (int x = 0; x < diff; x++) {
			for (int i = aLen + x + 1; i > x; i--) {
				a->digits[i] = a->digits[i-1];
			}	
			a->digits[0] = '0';
		}
	} else if (diff > 0) {
		for (int x = 0; x < diff; x++) {
			for (int i = bLen + x + 1; i > x; i--) {
				b->digits[i] = b->digits[i-1];
			}	
			b->digits[0] = '0';
		}
	}
}

// sintEquals(s1, s2) assigns each element of s1 digits 
// to the corrosponding element of s2 digits
// requires: s1 and s2 are not null 
void sintEquals(struct sint *s1, const struct sint *s2) {
	assert(s1 != NULL && s2 != NULL);
	for (int i = 0; s2->digits[i] != '\0'; i++) {
		s1->digits[i] = s2->digits[i];
		s1->digits[i+1] = '\0';
	}
}

int scomp(const struct sint *a, const struct sint *b) {
  assert(a != NULL && b != NULL);
	struct sint s1;
	struct sint s2;
	sintEquals(&s1, a);
	sintEquals(&s2, b);
	pad(&s1, &s2);
	return strcmp(s1.digits, s2.digits);
}

struct sint sadd(const struct sint *a, const struct sint *b) {
	assert(a != NULL && b != NULL);
	struct sint r = {"0"}; 
	struct sint s1;
	struct sint s2;
	sintEquals(&s1, a);
	sintEquals(&s2, b);
	pad(&s1, &s2);
	r.digits[strlen(s1.digits)] = '\0';
	int carry = 0;
	int sum = 0;
	for (int i = strlen(s1.digits)-1; i >= 0; i--) {
		sum = s1.digits[i] - '0' + s2.digits[i] - '0' + carry;
		if (sum > 9) {
			carry = 1;
			sum -= 10;
		} else {
			carry = 0;
		}	
		r.digits[i] = sum + '0';	
	}
	strim(&r);
	return r;
}
