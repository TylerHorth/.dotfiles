#include "intseq.h"
#include <stdbool.h>
#include <stdlib.h>
#include <assert.h>

// Tyler Horth
// CS136, Winter 2015
// Assignment 6, Problem 3a

int number_sum(int seq[], int len) {
	assert(seq != NULL);
	int sum = 0;
	for (int i = 0; i < len; i++) {
		sum += seq[i];
	}
	return sum;
}

int max_number(int seq[], int len) {
	assert(seq != NULL);
	int max = seq[0];
	for (int i = 1; i < len; i++) {
		if (seq[i] > max) {
			max = seq[i];
		} 
	}
	return max;
}

int min_number(int seq[], int len) {
	assert(seq != NULL);
	int min = seq[0];
	for (int i = 1; i < len; i++) {
		if (seq[i] < min) {
			min = seq[i];
		} 
	}
	return min;
}

int minmax_dist(int seq[], int len) {
	assert(seq != NULL);
	int min = seq[0];
	int max = seq[0];
	int minIdx = 0;
	int maxIdx = 0;
	for (int i = 1; i < len; i++) {
		if (seq[i] < min) {
			min = seq[i];
			minIdx = i;
		} else if (seq[i] > max) {
			max = seq[i];
			maxIdx = i;
		} 
	}
	int dist = minIdx - maxIdx;
	return (dist < 0) ? -dist : dist; 
}

float seq_avg(int seq[], int len) {
	assert(seq != NULL);
	float sum = 0.0;
	for (int i = 0; i < len; i++) {
		sum += seq[i];
	}
	return sum / len;
}

bool seq_has_duplicates(int seq[], int len) {
	assert(seq != NULL);
	for (int x = 0; x < len; x++) {
		for (int y = 0; y < len; y++) {
			if (seq[x] == seq[y] && x != y) {
				return 1;
			}
		}
	}
	return 0;
}

int seq_most_occurrences(int seq[], int len) {
	assert(seq != NULL);
	int count = 0;
	int leader = 0;
	int leaderCount = 0;
	for (int x = 0; x < len; x++) {
		count = 0;
		for (int y = 0; y < len; y++) {
			if (seq[x] == seq[y]) {
				count++;
			}
		}
		if (count > leaderCount) {
			leaderCount = count;
			leader = seq[x];
		}
	}
	return leader;
}
