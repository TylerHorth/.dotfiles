/**
 Tyler Horth
 CS136, Winter 2015
 Assignment 6, Problem 4b
 File: query.c
 Performs basic queries on a list of student scores
 */
#include <stdio.h>
#include <assert.h>
#include "score.h"

// example query using the foldl function from score.h
// Number of students with zero marks in final exam
int query_0(const struct score *data, int acc) {
  assert(data);
  return acc + (data->final == 0);
}

/* ---------------------------------------------------------- */
// Add your functions here
// You are not allowed to use any kind of loop (e.g., for, 
//          while or do..while loops) or recursion.
 
// query_1(data, acc) returns number of students who passed the course.
// requires: data
int query_1(const struct score *data, int acc) {
	assert(data);
	return ((data->clicker + data->assn + data->mid + data->final >= 50) 
		&& (data->assn >= 10) && (data->mid + data->final >= 38)) + acc;
}

// query_2(data, acc) returns number of students who only failed due
// to not passing the assignments.
// requires: data
int query_2(const struct score *data, int acc) {
	assert(data);
	return ((data->clicker + data->assn + data->mid + data->final >= 50) 
		&& (data->assn < 10) && (data->mid + data->final >= 38)) + acc;
}

// query_3b(data, acc) returns the largest total grade in the class
// requires: data
int query_3b(const struct score *data, int acc) {
  assert(data);
	int grade = data->clicker + data->assn + data->mid + data->final;
	if (grade > acc)
		return grade;
	else
		return acc;	
}

// query_3(data, acc) returns acc
// requires: data
// effects: prints student ids whose total grade match acc
int query_3(const struct score *data, int acc) {
	assert(data);
	int grade = data->clicker + data->assn + data->mid + data->final;
	if (grade == acc) {
		printf("%s\n", data->id);
	}
	return acc;
}

/* ---------------------------------------------------------- */

int main(void) {
  struct database db;
  if (read_database(&db) == true) {
    printf("query-0:%d\n", foldl(query_0, 0, &db));
    // call foldl using your query functions and print
    // the results.

    printf("query-1:%d\n", foldl(query_1, 0, &db));
    printf("query-2:%d\n", foldl(query_2, 0, &db));
    printf("query-3:\n");
		foldl(query_3, foldl(query_3b, 0, &db), &db);
  }
}
