#include "score.h"
#include <stdlib.h>
#include <assert.h>
#include <stdio.h>

// Tyler Horth
// CS136, Winter 2015
// Assignment 6, Problem 4a

bool read_database(struct database *db) {
	assert(db != NULL);
	char s[11] = "";
	int num = 0;
	int dataRead = 0;
	for (int i = 0; i < 100; i++) {
		if (i % 5 == 0) {
			if (scanf("%s", s) == EOF) {
				break;
			}
			dataRead = 1;
			db->count++;
			for (int n = 0; n < 11; n++) {
				(db->data[i/5]).id[n] = s[n];
			}
		} else if (i % 5 == 1) {
			scanf("%d", &num);
			(db->data[i/5]).clicker = num;	
		} else if (i % 5 == 2) {
			scanf("%d", &num);
			(db->data[i/5]).assn = num;	
		} else if (i % 5 == 3) {
			scanf("%d", &num);
			(db->data[i/5]).mid = num;	
		} else if (i % 5 == 4) {
			scanf("%d", &num);
			(db->data[i/5]).final = num;	
		}
	}
	return dataRead;
}

int foldl(int (*fn)(const struct score *scr, int acc),
            int init, const struct database *db) {
	assert(db != NULL);
	for (int i = 0; i < db->count; i++) {
		init = (*fn)(db->data + i, init);
	}
	return init;
}
